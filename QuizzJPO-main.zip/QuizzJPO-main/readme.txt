Les questions et les 4 possibilités de reponses sont enregistrées dans le dossier questions

Les réponses entrées par les candidats dans le dossier reponses_candidats

Les Vraies réponses dans reponses_vraies

Vous l'aurez compris la modification du fichier des questions se répercute sur 
le programme. Mais faites attention car pour des raisons de temps nous n'avons pas pu gérer tous les cas.
Par exemple, si une question est trop longue elle dépassera tout simplement de
l'écran. Idem pour les 4 reponses possibles.

A cause de la pandémie du coronavirus le projet a été interrompu et de ce fait la partie multijoueur est
tout simplement indisponible