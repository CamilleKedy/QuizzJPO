# QuizzJPO
A quiz game developed in C language with SDL 1.2 library for Prepavogt open days.
